﻿namespace FirstConsole
{
   

    internal class Program
    { 
        
        
        static void Main(string[] args)
        {

            #region Degisken Isimlendirme Yazim Prensipleri

            // Pascal Case => WriteLine
            // camel case => writeLine
            // snake case => write_line
            // kebap case =  write-line
            #endregion

            Console.WriteLine("Hello, World!");
            Console.WriteLine("Hello, Mars!");
        }
        
    }
   
}


