﻿using System.Diagnostics;

namespace DegiskenTanimlama
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Kisa Yollar
            /*
             * ctrl +k +s => region açmanizi saglar
             * ctrl + k +c => Yorum Satirina alir
             * ctrl + k + u => Yorum satirindan cikartir
             * 
             * Gerekli baglanti 
             * https://learn.microsoft.com/en-us/visualstudio/ide/default-keyboard-shortcuts-in-visual-studio?view=vs-2022
             */
            #endregion

            #region DEgisken Tanimalama Kurallari
            /*
             * 
             * Değişken adları, anlamlı ve açıklayıcı olmalıdır. Aynı zamanda belirli kurallara da uymalıdır.
             * İşte değişken isimlendirmeyle ilgili bazı kurallar:

            Değişken adı bir harfle başlamalıdır.Sayisal bir deger ile başlayamaz
            Değişken adı yalnızca harf, rakam ve alt çizgi (_) içerebilir.( ? $ % &  v.b isaretler iceremez
            Değişken adları büyük-küçük harf duyarlıdır.
                 writeLine , WriteLine farkli degiskenlerdir. 
            
            Özel bir anlamı olan anahtar kelimeler kullanılamaz.

            Örnek olarak, bir değişkeni “toplamSonucu” şeklinde adlandırmak, kodunuzu daha okunabilir hale getirir.
            int x,y,z; Bu şekilde kisa tanimlamalar yapmayiniz.
           
             * 
             * 
             * 
             * 
             * 
             */
            #endregion


            #region Ornek Degisken Tanimlamalari
            /*
                * Bir kisinin adini ,soyadini ,dogumtarihini ,ayakkabi numarasi ve 
                * Calisip Calismadigi ,TcNo , Gsm , email tutan degiskenler icad edelim 
                */

            //string adi,soyadi="Yilmaz"; // ilk deger atamasi 
            //DateTime dogumTarihi =DateTime.Now;
            //byte ayakNumarasi=44;
            //byte Numa11r22a33Ayakabi44 = 44;
            //byte? AyakNo = 33;
            //bool calisiyormu=true;
            //bool çalışıyormu =true; // Turkce karakter kullanmayin (Tavsiyedir. Normalde çalişir) 
            //adi = "ali";
            //string  tcno="12345678901";


            //Console.WriteLine(adi);
            //Console.WriteLine(soyadi);
            //Console.WriteLine("Hello, World!"); 
            #endregion

            #region Degisken Uzunluklari
            Console.WriteLine("byte bveri tipi ");
            Console.WriteLine(byte.MinValue);
            Console.WriteLine(byte.MaxValue);

            Console.WriteLine("short veri tipi ");
            Console.WriteLine(short.MinValue);
            Console.WriteLine(short.MaxValue);

            Console.WriteLine("ushort veri tipi ");
            Console.WriteLine(ushort.MinValue);
            Console.WriteLine(ushort.MaxValue);

            Console.WriteLine("ushort veri tipi ");
            Console.WriteLine(UInt16.MinValue);
            Console.WriteLine(UInt16.MaxValue);
            Console.WriteLine("int veri tipi ");
            Console.WriteLine(Int32.MinValue);
            Console.WriteLine(Int32.MaxValue);
            Console.WriteLine(int.MinValue);
            Console.WriteLine(int.MaxValue);


            Console.WriteLine("uint veri tipi ");
            Console.WriteLine(UInt32.MinValue);
            Console.WriteLine(uint.MaxValue);

            Console.WriteLine("long veri tipi ");
            Console.WriteLine(Int64.MinValue);
            Console.WriteLine(long.MaxValue);
            Console.WriteLine("ulong veri tipi ");
            Console.WriteLine(UInt64.MinValue);
            Console.WriteLine(ulong.MaxValue);

            #region Kusuratli sayilar
            Console.WriteLine("küsüratli sayilar ");
            Console.WriteLine("float veri tipi ");
            Console.WriteLine(float.MinValue);
            Console.WriteLine(Single.MaxValue);
            Console.WriteLine("double veri tipi ");
            Console.WriteLine(double.MinValue);
            Console.WriteLine(Double.MaxValue);

            Console.WriteLine("decimal  veri tipi ");
            Console.WriteLine(decimal.MinValue);
            Console.WriteLine(Decimal.MaxValue);
            #endregion

            #region var keyvord
            // var keywordu ile runtime esnasinda atanan veri ne ise
            // degisken tipi ona burunur.
            // daha sonrasinda ise degiskenin tipi degistirilemez
            var sayi = new DateTime(2024,8,7);
            //sayi = "sdfsd";

            var sayi2 = 10.5;
            var floatSayi = 10.5f;// sayinn sonuna f konulursa float olur
            var decimalSayi = 10.5m; //sayinin sonuna m konulursa decimal olur

            /*
             * Şirketteki personelin bilgilerini tutacak degiskenleri tanimlayin
             * Urun icin gerekli tanimlamalar ne olabilir.
             * 
             * Arkadasinizin telefon ve adres bilgilerini nasil tutarsiniz 
             */ 
                   
            #endregion
            #endregion
        }
    }
}
